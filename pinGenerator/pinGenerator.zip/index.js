var doc = require('aws-sdk');
var docClient = new doc.DynamoDB.DocumentClient();
var gpc = require('generate-pincode')

const getParams = {
    TableName: "UserPin"
}

exports.handler = async (event) => {
    // TODO implement
    const promise = docClient.scan(getParams).promise();
    const result = await promise;
    const data = result.Items;
    let pin = gpc(9);
    let dataSearch = [];
    for(var l in data){
            console.log(Object.entries(data[l]));
            dataSearch.push(Object.entries(data[l]));
    }   
    var search=dataSearch.flat(Infinity);
    while (dataSearch.includes(pin)){
         pin = gpc(9);
    }
};